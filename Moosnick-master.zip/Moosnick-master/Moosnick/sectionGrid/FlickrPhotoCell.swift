//
//  FlickrPhotoCell.swift
//  sectionGrid
//
//  Created by Jair P Ramirez on 4/10/18.
//  Copyright © 2018 Jair P Ramirez. All rights reserved.
//

import UIKit

class FlickrPhotoCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
}
